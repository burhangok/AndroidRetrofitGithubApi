package burhangok.retrofitson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {


    EditText usernameET;
    Button sendBTN;
    RecyclerView reposRV;

    public String username;

    GithubService githubService;

    ReposAdapter reposAdapter;

    LinearLayoutManager linearLayoutManager;

    List<Repo> repoList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        githubService =Config.retrofit.create(GithubService.class);

        linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        sendBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username=usernameET.getText().toString();

                callRequestApi().enqueue(new Callback<List<Repo>>() {
                    @Override
                    public void onResponse(retrofit2.Call<List<Repo>> call, Response<List<Repo>> response) {


                        repoList=response.body();

                        reposAdapter = new ReposAdapter(MainActivity.this,repoList);
                        reposRV.setLayoutManager(linearLayoutManager);

                        reposRV.setAdapter(reposAdapter);
                    }

                    @Override
                    public void onFailure(retrofit2.Call<List<Repo>> call, Throwable t) {

                        Toast.makeText(MainActivity.this, "Lütfen İnternet Bağlantınızı Kontrol Ediniz!", Toast.LENGTH_SHORT).show();
                    }
                });



            }
        });
    }

    void init() {

        usernameET = findViewById(R.id.username);
        sendBTN=findViewById(R.id.send);
        reposRV=findViewById(R.id.recyclerView);
    }



private retrofit2.Call<List<Repo>> callRequestApi () {

        return githubService.listRepos(this.username);
}


}
