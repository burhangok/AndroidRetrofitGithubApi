package burhangok.retrofitson;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ReposAdapter extends RecyclerView.Adapter<ReposAdapter.ReposHolder> {

    List<Repo> repoList = new ArrayList<>();

    LayoutInflater layoutInflater;

    public ReposAdapter(Activity activity,List<Repo> repoList) {
        this.layoutInflater= (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.repoList = repoList;
    }

    @NonNull
    @Override
    public ReposHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View rowView = layoutInflater.inflate(R.layout.row_layout,null);

        ReposHolder reposHolder = new ReposHolder(rowView);


        return reposHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReposHolder reposHolder, int i) {

        Repo repoTmp = repoList.get(i);
        reposHolder.nameTV.setText(repoTmp.getName());
        reposHolder.descTV.setText(repoTmp.getDescription());



    }

    @Override
    public int getItemCount() {
        return repoList.size();
    }

    class ReposHolder extends RecyclerView.ViewHolder {

        TextView nameTV;
        TextView descTV;

        public ReposHolder(@NonNull View itemView) {
            super(itemView);

            nameTV=itemView.findViewById(R.id.name);
            descTV=itemView.findViewById(R.id.description);
        }
    }
}
