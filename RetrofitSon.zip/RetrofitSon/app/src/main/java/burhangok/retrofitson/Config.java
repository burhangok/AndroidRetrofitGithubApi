package burhangok.retrofitson;


import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static burhangok.retrofitson.Config.retrofit;

public class Config {

  public static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();
}
